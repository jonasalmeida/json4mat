%Publishes manual
close all;web(publish('json4mat_pub.m'))
web(publish('json4mat_pub.m','pdf'))